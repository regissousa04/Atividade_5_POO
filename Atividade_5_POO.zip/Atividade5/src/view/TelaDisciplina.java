package view;

import java.text.ParseException;
import java.util.List;
import java.util.Scanner;
import model.dao.DisciplinaDAO;
import model.dao.FactoryDAO;
import model.entities.Disciplina;

public class TelaDisciplina {
	
	static DisciplinaDAO disciplinaDao = FactoryDAO.createDisciplinaDAO();
	
	@SuppressWarnings("resource")
	public static Scanner menuDisciplina(Scanner console) throws InterruptedException, ParseException {

		int opcao = 0;
		do {
			System.out.println("\n\n");
			System.out.println("1 - Cadastrar");
			System.out.println("2 - Listar");
			System.out.println("3 - Alterar");
			System.out.println("4 - Excluir");
			opcao = console.nextInt();
			console.nextLine();
			
			switch (opcao) {
			case 1: console = cadastrar(console);
					break;
			case 2:	console = listar(console);
					break;
			case 3: console = alterar(console);
					break;
			case 4: console = excluir(console);
					break;
			}
		} while (opcao != 0);
		return console;
	}
	
	private static Scanner cadastrar(Scanner console) throws ParseException {
		
		Disciplina disciplina = new Disciplina();
		
		System.out.println("\n");
		System.out.print("Nome: "); 
		disciplina.setNomedisciplina(console.nextLine());
		System.out.println("\n");
		System.out.print("Carga Hor�ria: "); 
	    disciplina.setCargahoraria(console.nextInt());
		System.out.println("\n");
	    
	    disciplinaDao.insert(disciplina);
	    console.nextLine();
	    return console;
	} 
	
	private static Scanner listar(Scanner console) {
				
		List<Disciplina> disciplinas = disciplinaDao.findAll();

		System.out.println("\n");
		for(Disciplina disciplina : disciplinas) { 
			System.out.println("        " + disciplina.getIddisciplina()
							 + "\t" 		+ disciplina.getCargahoraria() 
							 + "\t\t" 		+ disciplina.getNomedisciplina());
		}
		console.nextLine();
		return console;
	}
	
	private static Scanner alterar(Scanner console) throws ParseException {
		
		Disciplina disciplina = new Disciplina(); 
		
		System.out.println("\n"); 
		System.out.print(" Digite o ID: "); 
		disciplina.setIddisciplina(console.nextInt()); 
		console.nextLine();
		  
		System.out.print("Digite Nome Disciplina: "); 
		disciplina.setNomedisciplina(console.nextLine());

		System.out.print("Carga Hor�ria: ");
		disciplina.setCargahoraria(console.nextInt()); 
		console.nextLine();
		disciplinaDao.update(disciplina);
		
		console.nextLine();
		return console;
	} 
	
	private static Scanner excluir(Scanner console) throws ParseException {

		System.out.println("\n");
		System.out.print("Digite o Id: ");
		int id = console.nextInt();
		console.nextLine();
		disciplinaDao.deleteByid(id);
		console.nextLine();
		return console;
	}
}
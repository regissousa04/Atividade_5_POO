package model.dao;

import java.util.List;

import model.entities.Aluno;

public interface AlunoDAO {

	void insert(Aluno aluno);
	void update(Aluno aluno);
	void deleteByid(Integer id);
	Aluno findByid(Integer id);
	List<Aluno> findAll();
}
